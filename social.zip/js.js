const name="abhishek";

if(name == "abhishek"){
    console.log("u name is too good");
} else{
  
    console.log(name,"this is not the name");

}
